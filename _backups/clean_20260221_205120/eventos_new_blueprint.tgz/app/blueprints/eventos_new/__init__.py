from flask import Blueprint

eventos_new_bp = Blueprint(
    "eventos_new",
    __name__,
    template_folder="../../templates"
)

from . import routes
